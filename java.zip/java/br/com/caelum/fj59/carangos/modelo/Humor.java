package br.com.caelum.fj59.carangos.modelo;

/**
 * Created by erich on 7/25/13.
 */
public enum Humor {
    ANIMADO, INDIFERENTE, TRISTE
}
